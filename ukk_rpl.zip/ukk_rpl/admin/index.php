<?php
session_start();
include '../config/koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>website galeri foto</title>
  <link rel="stylesheet" type="text/css" href="../asset/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
  <style>
    .liked-heart {
      color: red;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
      <a class="navbar-brand" href="index.php">website galeri foto</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse mt-2" id="navbarNavA1tMarkup">
        <div class="navbar-nav me-auto">
          <a href="home.php" class="nav-link">Home</a>
          <a href="album.php" class="nav-link">Album</a>
          <a href="foto.php" class="nav-link">Foto</a>
        </div>
        <a href="../config/aksi_logout.php" class="btn btn-outline-danger m-1">Keluar</a>
      </div>
    </div>
  </nav>

  <div class="container mt-2">
    <div class="row">
      <?php
      $userid = $_SESSION['userid'];
      $query = mysqli_query($koneksi, "SELECT * FROM foto");
      while ($data = mysqli_fetch_array($query)) {
        $fotoid = $data['fotoid'];

        $cek_suka_query = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE fotoid='$fotoid' AND userid='$userid'");
        $is_liked = mysqli_num_rows($cek_suka_query) > 0;

        $like_query = mysqli_query($koneksi, "SELECT COUNT(*) as total_likes FROM likefoto WHERE fotoid='$fotoid'");
        $total_likes = mysqli_fetch_assoc($like_query)['total_likes'];

        $comment_query = mysqli_query($koneksi, "SELECT COUNT(*) as total_comments FROM komentarfoto WHERE fotoid='$fotoid'");
        $total_comments = mysqli_fetch_assoc($comment_query)['total_comments'];
      ?>
        <div class="col-md-3 mt-2">
          <a type="button" data-bs-toggle="modal" data-bs-target="#komentar<?php echo $fotoid ?>">
            <div class="card">
              <img style="height: 12rem;" src="../asset/img/<?php echo $data['lokasifile'] ?>" class="card-img-top" title="<?php echo $data['judulfoto'] ?>">
              <div class="card-footer text-center">
                <?php if ($is_liked) { ?>
                  <a href="../config/proses_like.php?redirect=index&id=<?php echo $fotoid ?>" type="submit" name="batalsuka" class="text-decoration-none">
                    <i class="fa fa-heart liked-heart"></i>
                  </a>
                <?php } else { ?>
                  <a href="../config/proses_like.php?redirect=index&id=<?php echo $fotoid ?>" type="submit" name="suka" class="text-decoration-none">
                    <i class="fa-regular fa-heart"></i>
                  </a>
                <?php } ?>
                <?php echo $total_likes; ?> Suka

                <a href="#" class="text-decoration-none">
                  <i class="fa-regular fa-comment"></i>
                </a>
                <?php echo $total_comments; ?> komentar
              </div>
            </div>
          </a>

          <!-- Modal -->
          <div class="modal fade" id="komentar<?php echo $fotoid ?>" tabindex="-1">
            <div class="modal-dialog modal-xl">
              <div class="modal-content">
                <div class="modal-body">
                  <div class="row">
                    <div class="col-md-8">
                      <img src="../asset/img/<?php echo $data['lokasifile'] ?>" class="card-img-top" title="<?php echo $data['judulfoto'] ?>">
                    </div>
                    <div class="col-md-4">
                      <div class="mt-2">
                        <div class="overflow-auto">
                          <div class="sticky-top">
                            <strong><?php echo $data['judulfoto'] ?></strong> <br>
                            <span class="badge bg-secondary"><?php echo date('d F Y', strtotime($data['tanggalunggah'])); ?></span>
                          </div>
                          <hr>
                          <?php
                          $komentar = mysqli_query($koneksi, "SELECT * FROM komentarfoto WHERE fotoid ='$fotoid'");
                          while ($row = mysqli_fetch_array($komentar)) {
                            echo "<div class='mb-2'>" . htmlspecialchars($row['isikomentar']) . "</div><hr>";
                          }
                          ?>
                          <div class="sticky-bottom">
                            <form action="../config/proses_komentar.php" method="POST">
                              <div class="input-group">
                                <input type="hidden" name="fotoid" value="<?php echo $fotoid ?>">
                                <input type="text" name="isikomentar" class="form-control" placeholder="Tambah Komentar" required>
                                <div class="input-group-append">
                                  <button type="submit" name="simpan" value="simpan" class="btn btn-primary">Kirim</button>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php } ?>
    </div>
  </div>

  <footer class="d-flex justify-content-center border-top mt-3 bg-light fixed-bottom">
    <p>&copy, UKK RPL 2024 | Nama Peserta</p>
  </footer>

  <script type="text/javascript" src="../asset/js/bootstrap.min.js"></script>
</body>

</html>
