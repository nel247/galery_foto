<?php 
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'aplikasi_galeripoto';

$koneksi = mysqli_connect($hostname,$userdb,$passdb,$namedb, 3306);


?>
