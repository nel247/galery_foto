<?php
session_start();
include 'koneksi.php';


$fotoid = $_GET['id'];
$userid = $_SESSION['userid'];

$cek_suka = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE fotoid='$fotoid' AND userid='$userid'");


if (mysqli_num_rows($cek_suka) == 1) {
    while ($row = mysqli_fetch_array($cek_suka)) {
        $likeid = $row['likeid'];
        $query = mysqli_query($koneksi, "DELETE FROM likefoto WHERE likeid='$likeid'");
    }
} else {
    $tanggallike = date('Y-m-d H:i:s');
    $q = "INSERT INTO likefoto (fotoid,userid,tanggallike) VALUES('$fotoid', '$userid', '$tanggallike')";
    $query = mysqli_query($koneksi, $q);
}


$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'home';
if ($redirect == 'index') {
    echo "<script>
    location.href='../admin/index.php';
    </script>";
} else {
    echo "<script>
    location.href='../admin/home.php';
    </script>";
}


