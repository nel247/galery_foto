<?php
session_start();
include 'koneksi.php';

if (isset($_POST['simpan'])) {
    $fotoid = $_POST['fotoid'];
    $userid = $_SESSION['userid'];
    $isikomentar = $_POST['isikomentar'];
    $tanggalkometar= date('Y-m-d');


    $query = mysqli_query($koneksi, "INSERT INTO komentarfoto (fotoid, isikomentar, tanggalkomentar, userid) VALUES ('$fotoid', '$isikomentar', '$tanggalkometar', '$userid')");

    echo "<script>
    location.href = '../admin/index.php';
    </script>";
}
