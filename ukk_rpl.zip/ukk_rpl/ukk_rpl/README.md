## Cara install

- Download dari github
- Pindahkan foldernya ke dalam folder `htdocs`
- Buat database dengan nama `aplikasi_galeripoto`
- Import file `aplikasi_galeripoto.sql` ke database `aplikasi_galeripoto`
- Klik kanan di folder img
- Buka di browser `http://localhost/UKK_RPL`
