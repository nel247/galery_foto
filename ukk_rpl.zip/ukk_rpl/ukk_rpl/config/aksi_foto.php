<?php
session_start();
include 'koneksi.php';

if (isset($_POST['action']) && $_POST['action'] == 'hapus') {
    $fotoid = (int)$_POST['fotoid'];
    $query = "DELETE FROM foto WHERE fotoid = $fotoid";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>
                alert('Data berhasil dihapus!');
                window.location.href = '../admin/foto.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus data: " . mysqli_error($koneksi) . "');
                window.location.href = '../admin/foto.php';
              </script>";
    }
}

if (isset($_POST['action']) && $_POST['action'] == 'edit') {
    $fotoid = (int)$_POST['fotoid'];
    $judulfoto = mysqli_real_escape_string($koneksi, $_POST['judulfoto']);
    $deskripsifoto = mysqli_real_escape_string($koneksi, $_POST['deskripsifoto']);
    $albumid = (int)$_POST['albumid'];

    $query = "UPDATE foto SET judulfoto = '$judulfoto', deskripsifoto = '$deskripsifoto', albumid = $albumid";
    if (!empty($_FILES['lokasifile']['name'])) {
        $lokasi = '../asset/img/';
        $imageFileType = strtolower(pathinfo($_FILES['lokasifile']['name'], PATHINFO_EXTENSION));
        $namafoto = rand() . '-' . time() . '.' . $imageFileType;
        $target_file = $lokasi . $namafoto;
        $uploadOk = 1;

        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES['lokasifile']['tmp_name'], $target_file)) {
                $query .= ", lokasifile = '$namafoto'";
                // Hapus file lama
                $query_lama = "SELECT lokasifile FROM foto WHERE fotoid = $fotoid";
                $result_lama = mysqli_query($koneksi, $query_lama);
                $data_lama = mysqli_fetch_array($result_lama);
                unlink('../asset/img/' . $data_lama['lokasifile']);
            } else {
                echo "<script>
                        alert('Maaf, terjadi kesalahan saat mengupload file!');
                        window.location.href = '../admin/foto.php';
                      </script>";
                exit;
            }
        }
    }
    $query .= " WHERE fotoid = $fotoid";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>
                alert('Data berhasil diedit!');
                window.location.href = '../admin/foto.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal mengedit data: " . mysqli_error($koneksi) . "');
                window.location.href = '../admin/foto.php';
              </script>";
    }
}





// Set direktori upload
$lokasi = '../asset/img/';
$imageFileType = strtolower(pathinfo($_FILES['lokasifile']['name'], PATHINFO_EXTENSION));
$namafoto = rand() . '-' . time() . '.' . $imageFileType;
$target_file = $lokasi . $namafoto;
$uploadOk = 1;

// Jika semua pengecekan ok, coba upload
if ($uploadOk == 1) {
    if (move_uploaded_file($_FILES['lokasifile']['tmp_name'], $target_file)) {
        // Simpan ke database
        $judulfoto = mysqli_real_escape_string($koneksi, $_POST['judulfoto']);
        $deskripsifoto = mysqli_real_escape_string($koneksi, $_POST['deskripsifoto']);
        $tanggalunggah = date('Y-m-d');
        $albumid = (int)$_POST['albumid'];
        $userid = (int)$_SESSION['userid'];

        $query = "INSERT INTO foto (judulfoto, deskripsifoto, tanggalunggah, lokasifile, albumid, userid)
                 VALUES ('$judulfoto', '$deskripsifoto', '$tanggalunggah', '$namafoto', $albumid, $userid)";

        if (mysqli_query($koneksi, $query)) {
            echo "<script>
                    alert('File berhasil diupload dan data disimpan!');
                    window.location.href = '../admin/foto.php';
                  </script>";
        } else {
            unlink($target_file); // Hapus file jika gagal menyimpan ke database
            echo "<script>
                    alert('Gagal menyimpan data ke database: " . mysqli_error($koneksi) . "');
                    window.location.href = '../admin/foto.php';
                  </script>";
        }
    } else {
        echo "<script>
                alert('Maaf, terjadi kesalahan saat mengupload file!');
                window.location.href = '../admin/foto.php';
              </script>";
    }
}

// Tutup koneksi
mysqli_close($koneksi);
