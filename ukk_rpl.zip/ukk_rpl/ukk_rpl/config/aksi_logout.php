<?php 
session_start();
session_destroy();
echo "<script>
alert('Logout Berhasil');
location.href='../asset/login.php';
</script>";

$sql = mysqli_query($koneksi, "INSERT INTO album VALUES('','$namaalbum','$deskripsi','$tanggal','userid')");

echo "<script>
alert('Data Berhasil disimpan!');
location.href='../admin/album.php';
</script>";
?>