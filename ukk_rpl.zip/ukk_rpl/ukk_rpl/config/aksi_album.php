<?php
session_start();
include 'koneksi.php';


if (isset($_POST['tambah'])) {
    $namaalbum = $_POST['namaalbum'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = date('Y-m-d');
    $userid = $_SESSION['userid'];

    $sql = mysqli_query($koneksi, "INSERT INTO album (namaalbum, deskripsi, tanggalbuat, userid) VALUES ('$namaalbum', '$deskripsi', '$tanggal', '$userid')");

    if ($sql) {
        echo "<script>
            alert('Data berhasil disimpan!');
            window.location.href = '../admin/album.php';
        </script>";
    } else {
        echo "<script>
            alert('Data gagal disimpan: " . mysqli_error($koneksi) . "');
            window.location.href = '../admin/album.php';
        </script>";
    }
}

if (isset($_POST['edit'])) {
    $albumid = $_POST['albumid'];
    $namaalbum = $_POST['namaalbum'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = date('Y-m-d');

    $sql = mysqli_query($koneksi, "UPDATE album SET namaalbum='$namaalbum', deskripsi='$deskripsi', tanggalbuat='$tanggal' WHERE albumid='$albumid'");

    if ($sql) {
        echo "<script>
            alert('Data berhasil diperbarui!');
            location.href='../admin/album.php';
        </script>";
    } else {
        echo "<script>
            alert('Data gagal diperbarui: " . mysqli_error($koneksi) . "');
            location.href='../admin/album.php';
        </script>";
    }
}

if (isset($_POST['hapus'])) {
    $albumid = $_POST['albumid'];

    $sql = mysqli_query($koneksi, "DELETE FROM album WHERE albumid='$albumid'");

    if ($sql) {
        echo "<script>
            alert('Data berhasil dihapus!');
            location.href='../admin/album.php';
        </script>";
    } else {
        echo "<script>
            alert('Data gagal dihapus: " . mysqli_error($koneksi) . "');
            location.href='../admin/album.php';
        </script>";
    }
}
