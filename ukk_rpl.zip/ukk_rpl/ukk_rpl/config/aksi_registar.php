<?php 

include 'koneksi.php';

$username = $_POST['username'];
$password = md5($_POST['password']);
$email = $_POST['email'];
$namaLengkap = $_POST['namalengkap'];
$alamat = $_POST['alamat'];

$sql = mysqli_query($koneksi,"INSERT INTO user (username, password, email, namalengkap, alamat) VALUES ('$username','$password','$email','$namaLengkap','$alamat')");


echo "<script>
alert('Pendaftaran akun berhasil');
location.href='../asset/login.php';
</script>";
 
?>
