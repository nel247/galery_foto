<?php
session_start();
include '../config/koneksi.php';

if (!isset($_SESSION['userid'])) {
    echo "<script>
        alert('Anda harus login terlebih dahulu!');
        location.href='login.php';
    </script>";
}


?>
